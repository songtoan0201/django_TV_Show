from django.apps import AppConfig


class TvshowConfig(AppConfig):
    name = 'TVShow'
